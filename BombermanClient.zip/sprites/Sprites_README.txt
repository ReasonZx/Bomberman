For buttons font:
FixedSys
Size 72
Bold